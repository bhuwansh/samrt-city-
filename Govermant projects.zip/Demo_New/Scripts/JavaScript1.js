function test() {

var response;

$.ajax({
    type: 'Post',
    url: url + 'GetTEST',
    contentType: 'application/json; charset=utf-8',
    dataType: 'json',
    success: function (msg) {
        alert(msg);
    },

    error: function (e) {
        alert("Error  : " + e.statusText);
    }
});