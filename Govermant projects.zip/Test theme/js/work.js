﻿window.onload = function () {

    GetCamStatus();

    GetRPStatus();

    GetBrStatus();
    GetCashCodeStatus();
};



var myVar;
var newtxt = "";
var i = 0;
function SetTimeOut() {
    myVar = setInterval(GetNoteDetails, 5000);
}

function ClearTimeOut() {
    clearInterval(myVar);
    StopNoteAccept();
}

function Init() {


    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/1/" + document.getElementById('txtAmnt').value + "/0",
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
        alert(response);
    });
}





function GetNoteDetails() {

    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/4/0/0",
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
        // alert(response);
        document.getElementById('lblNoteDetails').innerHTML = response;
    });
}

function StopNoteAccept() {

    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/5/0/0",
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
        // alert(response);
        document.getElementById('lblNoteDetails').innerHTML = response;
        ClearInterval(myVar);
    });
}
function ascii(a) { return a.charCodeAt(0); }

function Print() {

    var txt = document.getElementById("txtPrintData").value;
    newtxt = "";
    var j = "";

    for (var i = 0; i < txt.length; i++) {
        j = ascii(txt[i]);
        if (j <= 32 || j == 47 || j == 92 || j == 127 || j == 35 || j == 37 || j == 46 || j == 63 || j == 64 || j == 126) {
            newtxt += "@~~~" + j + "@";
        }
        else {
            newtxt += txt[i];
        }
    }
    // alert(newtxt);
    printer();






}

function printer() {
    if (newtxt.length > 25) {

        var res = newtxt.substr(0, 25);
        newtxt = newtxt.substr(25);

        var settings =
        {
            "async": true,
            "crossDomain": true,
            "url": "http://127.0.0.1:1234/api/websites/2/1/" + res,
            "method": "GET",
            "headers":
            {
                "Cache-Control": "no-cache",
                "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
            }
        }


        $.ajax(settings).done(function (response) {
            if (response == "MORE")
                printer();
        });

    }
    else {
        var settings =
        {
            "async": true,
            "crossDomain": true,
            "url": "http://127.0.0.1:1234/api/websites/2/0/" + newtxt,
            "method": "GET",
            "headers":
            {
                "Cache-Control": "no-cache",
                "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
            }
        }


        $.ajax(settings).done(function (response) {
            alert(response);
        });
    }

}



function DeInit() {

    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/4",
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
        alert(response);
    });
}

function ClickImage() {
    

    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/7/0/" + document.getElementById('txtTxnData').value,
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
        
        // alert(response);
        //document.getElementById('ImgPath').innerHTML = response;
        document.getElementById('Image').src = "data:image/jpg;base64," + response;


    });
}

function GetCamStatus() {
    
    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/6/0/0",
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
        
        // alert(response);

        if (response == "Camera Application and Device are ok") {
            document.getElementById('CameraState1').style.backgroundColor = "green";
        
        }
        else {
            document.getElementById('CameraState1').style.backgroundColor = "Red";
        }
        document.getElementById('CameraState').innerHTML = response;

    });
}

function GetRPStatus() {

    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/3/0/0",
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
   
        if (response == "Printer Online") {
            document.getElementById('RPStatus1').style.backgroundColor = "green";
        }
        else {
           
                document.getElementById('RPStatus1').style.backgroundColor = "Red";
           
        }

        document.getElementById('lblPrinterStatus').innerHTML = response;
       
    });
}

function GetBrStatus() {
   
    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/13/0/0",
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
      
        if (response == "Connected") {
            document.getElementById('BPStatus1').style.backgroundColor = "green";
        }
        else {

            document.getElementById('BPStatus1').style.backgroundColor = "Red";

        }

        document.getElementById('lblBarcodeStatus').innerHTML = response;

    });
}
function GetCashCodeStatus() {

    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/14/0/0",
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
    
        if (response == "connected") {
            document.getElementById('GSRStatus1').style.backgroundColor = "green";
        }
        else {

            document.getElementById('GSRStatus1').style.backgroundColor = "Red";

        }

      //-  document.getElementById('lblBarcodeStatus').innerHTML = response;

    });
}


function RecPrint() {
    document.getElementById("Rec").style.display = "block";
    document.getElementById("Cash").style.display = "none";
    document.getElementById("Cam").style.display = "none";
    document.getElementById("RecBtn").style.backgroundColor = "green";
    document.getElementById("CashButton").style.backgroundColor = "transparent";
    document.getElementById("CamButton").style.backgroundColor = "transparent";
    document.getElementById("Doc").style.backgroundColor = "transparent";
    document.getElementById("DocScanner").style.display = "none";
    document.getElementById("BarcodeScanner").style.display = "none";
    document.getElementById("Bar").style.backgroundColor = "transparent";
    document.getElementById('Image').src = "kiosk.png"
}
function CashAcc() {
    document.getElementById("Rec").style.display = "none";
    document.getElementById("Cash").style.display = "block";
    document.getElementById("Cam").style.display = "none";
    document.getElementById("RecBtn").style.backgroundColor = "transparent";
    document.getElementById("CashButton").style.backgroundColor = "green";
    document.getElementById("CamButton").style.backgroundColor = "transparent";
    document.getElementById("Doc").style.backgroundColor = "transparent";
    document.getElementById("DocScanner").style.display = "none";
    document.getElementById("BarcodeScanner").style.display = "none";
    document.getElementById("Bar").style.backgroundColor = "transparent";
    document.getElementById('Image').src = "kiosk.png"
}
function ActivateCam() {
    document.getElementById("Rec").style.display = "none";
    document.getElementById("Cash").style.display = "none";
    document.getElementById("Cam").style.display = "block";
    document.getElementById("RecBtn").style.backgroundColor = "transparent";
    document.getElementById("CashButton").style.backgroundColor = "transparent";
    document.getElementById("CamButton").style.backgroundColor = "green";
    document.getElementById("Doc").style.backgroundColor = "transparent";
    document.getElementById("DocScanner").style.display = "none";
    document.getElementById("BarcodeScanner").style.display = "none";
    document.getElementById("Bar").style.backgroundColor = "transparent";
    document.getElementById('Image').src = "kiosk.png"
}
function ActivateDocScanner() {
    document.getElementById("Rec").style.display = "none";
    document.getElementById("Cash").style.display = "none";
    document.getElementById("Cam").style.display = "none";
    document.getElementById("RecBtn").style.backgroundColor = "transparent";
    document.getElementById("CashButton").style.backgroundColor = "transparent";
    document.getElementById("CamButton").style.backgroundColor = "transparent";
    document.getElementById("Doc").style.backgroundColor = "green";
    document.getElementById("DocScanner").style.display = "block";
    document.getElementById("BarcodeScanner").style.display = "none";
    document.getElementById("Bar").style.backgroundColor = "transparent";
    document.getElementById('Image').src = "kiosk.png"
}
function ActivateBarScanner() {
    document.getElementById("Rec").style.display = "none";
    document.getElementById("Cash").style.display = "none";
    document.getElementById("Cam").style.display = "none";
    document.getElementById("RecBtn").style.backgroundColor = "transparent";
    document.getElementById("CashButton").style.backgroundColor = "transparent";
    document.getElementById("CamButton").style.backgroundColor = "transparent";
    document.getElementById("Doc").style.backgroundColor = "transparent";
    document.getElementById("DocScanner").style.display = "none";
    document.getElementById("BarcodeScanner").style.display = "block";
    document.getElementById("Bar").style.backgroundColor = "green";
    document.getElementById('Image').src = "kiosk.png";
}

function StartScan() {

    debugger;
    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/8/0/" + document.getElementById("txtScannerData").value,
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
        debugger;
        document.getElementById('ImageDocument').src = "data:image/jpg;base64," + response;
    });

}

function StartPreview() {
    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/9/0/0",
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
        alert(response);
    });

}


function StopPreview() {
    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/10/0/0",
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
        alert(response);
    });

}
function StartBarcodeScan() {
    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/11/0/0",
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
        document.getElementById('Barcodereads').innerHTML =  response;
    });
}
function KioskID() {
    var settings =
    {
        "async": true,
        "crossDomain": true,
        "url": "http://127.0.0.1:1234/api/websites/12/0/0",
        "method": "GET",
        "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
    }

    $.ajax(settings).done(function (response) {
        alert("Your KioskID is: Lipi" + response);
    });
}


